"""
Проверка подписи initData, которую Telegram WebApp передаёт фронтенду.
Это единственный надёжный способ узнать, какой реальный пользователь
Telegram открыл мини-апп (нельзя доверять данным, присланным просто в JSON от клиента).

Документация: https://core.telegram.org/bots/webapps#validating-data-received-via-the-mini-app
"""
import hashlib
import hmac
import json
import time
from urllib.parse import parse_qsl


class InitDataError(Exception):
    pass


def validate_init_data(init_data: str, bot_token: str, max_age_seconds: int = 86400) -> dict:
    """Возвращает распарсенный dict с полем 'user', либо кидает InitDataError."""
    if not init_data:
        raise InitDataError("init data is empty")

    parsed = dict(parse_qsl(init_data, strict_parsing=True))
    received_hash = parsed.pop("hash", None)
    if not received_hash:
        raise InitDataError("hash missing")

    data_check_string = "\n".join(f"{k}={v}" for k, v in sorted(parsed.items()))

    secret_key = hmac.new(b"WebAppData", bot_token.encode(), hashlib.sha256).digest()
    computed_hash = hmac.new(secret_key, data_check_string.encode(), hashlib.sha256).hexdigest()

    if not hmac.compare_digest(computed_hash, received_hash):
        raise InitDataError("invalid signature")

    auth_date = int(parsed.get("auth_date", "0"))
    if max_age_seconds and (time.time() - auth_date) > max_age_seconds:
        raise InitDataError("init data expired")

    result = dict(parsed)
    if "user" in result:
        result["user"] = json.loads(result["user"])
    return result
